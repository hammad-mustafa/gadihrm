/*
SQLyog Community v11.52 (64 bit)
MySQL - 10.1.8-MariaDB : Database - gaditek_employee_portal
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`gaditek_employee_portal` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `gaditek_employee_portal`;

/*Table structure for table `general_app_config` */

DROP TABLE IF EXISTS `general_app_config`;

CREATE TABLE `general_app_config` (
  `key` varchar(100) NOT NULL,
  `value` varchar(512) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `general_app_config` */

insert  into `general_app_config`(`key`,`value`) values ('checkins_access','all'),('year_split','4');

/*Table structure for table `general_authentication` */

DROP TABLE IF EXISTS `general_authentication`;

CREATE TABLE `general_authentication` (
  `user_id` int(11) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` enum('active','inactive','deleted','suspended') NOT NULL DEFAULT 'inactive',
  KEY `FK_general_account` (`user_id`),
  CONSTRAINT `FK_general_account` FOREIGN KEY (`user_id`) REFERENCES `hrm_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `general_authentication` */

insert  into `general_authentication`(`user_id`,`username`,`password`,`status`) values (1,'hammey555','aGFtbWFkMTIz','active');

/*Table structure for table `general_fiscal_year` */

DROP TABLE IF EXISTS `general_fiscal_year`;

CREATE TABLE `general_fiscal_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year_name` varchar(10) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `general_fiscal_year` */

insert  into `general_fiscal_year`(`id`,`year_name`,`status`,`created`) values (1,'2015-2016','active','2016-03-10 14:57:57');

/*Table structure for table `general_fiscal_year_division` */

DROP TABLE IF EXISTS `general_fiscal_year_division`;

CREATE TABLE `general_fiscal_year_division` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fiscal_year_id` int(11) NOT NULL,
  `divison_name` varchar(24) NOT NULL COMMENT 'JAN - MAR 2016',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `general_fiscal_year_division` */

insert  into `general_fiscal_year_division`(`id`,`fiscal_year_id`,`divison_name`,`status`,`created`) values (1,1,'JAN-MAR 2016','active','2016-03-10 14:58:32'),(2,1,'APR-JUN 2016','inactive','2016-03-10 14:58:44');

/*Table structure for table `general_forget_password` */

DROP TABLE IF EXISTS `general_forget_password`;

CREATE TABLE `general_forget_password` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('active','inactive','deleted','emailed') NOT NULL DEFAULT 'active',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `general_forget_password` */

/*Table structure for table `general_roles` */

DROP TABLE IF EXISTS `general_roles`;

CREATE TABLE `general_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(64) NOT NULL DEFAULT '0',
  `role_code` varchar(16) NOT NULL DEFAULT '0',
  `status` enum('active','inactive','deleted','suspended') NOT NULL DEFAULT 'inactive',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `general_roles` */

insert  into `general_roles`(`id`,`role_name`,`role_code`,`status`) values (1,'user','user','active'),(2,'dashboard','dashboard','active'),(3,'report','rpt','active'),(4,'attendance','att','active'),(5,'active directory','ad','active'),(6,'job listing','jl','active'),(7,'payslips','ps','active'),(8,'idea board','ib','active'),(9,'ticket system','ts','active'),(10,'checkins','chk','active'),(11,'calendar','cl','active'),(12,'poll','poll','active'),(13,'targets','trg','active'),(14,'achievements','ach','active'),(15,'trainings','trn','active'),(16,'feed back','fb','active'),(17,'administrative form','af','active');

/*Table structure for table `general_user_role` */

DROP TABLE IF EXISTS `general_user_role`;

CREATE TABLE `general_user_role` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `general_user_role` */

insert  into `general_user_role`(`user_id`,`role_id`) values (1,8),(1,7),(1,6),(1,5),(1,4),(1,3),(1,2),(1,1),(1,9),(1,10),(1,11),(1,12);

/*Table structure for table `hrm_cadidate` */

DROP TABLE IF EXISTS `hrm_cadidate`;

CREATE TABLE `hrm_cadidate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate_name` varchar(64) NOT NULL DEFAULT 'candidate',
  `candidate_email` varchar(256) NOT NULL,
  `candidate_password` varchar(32) NOT NULL,
  `candidate_contact` varchar(16) NOT NULL,
  `mode_of_insert` enum('referral','self') NOT NULL DEFAULT 'self',
  `referral_id` int(11) NOT NULL DEFAULT '0',
  `candidate_status` enum('active','inactive','rejected','shortlisted') NOT NULL DEFAULT 'active',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_cadidate` */

/*Table structure for table `hrm_candidate_files` */

DROP TABLE IF EXISTS `hrm_candidate_files`;

CREATE TABLE `hrm_candidate_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate_id` int(11) NOT NULL,
  `file_name` varchar(256) NOT NULL DEFAULT 'file',
  `file_type` varchar(64) NOT NULL,
  `file_link` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_candidate_files` */

/*Table structure for table `hrm_candidate_history` */

DROP TABLE IF EXISTS `hrm_candidate_history`;

CREATE TABLE `hrm_candidate_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `interviewer_id` int(11) NOT NULL COMMENT 'employee id',
  `post_action` enum('shortlist','reject','pending','deffered') NOT NULL DEFAULT 'pending',
  `schedule_date` datetime NOT NULL,
  `remarks` text,
  `history_status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_candidate_history` */

/*Table structure for table `hrm_checkins` */

DROP TABLE IF EXISTS `hrm_checkins`;

CREATE TABLE `hrm_checkins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `reviewed_emp_id` int(11) NOT NULL,
  `emotion` enum('cool','happy','love','bored','sad','angry') NOT NULL DEFAULT 'cool',
  `rating` enum('1','2','3','4','5','6','7','8','9','10') NOT NULL DEFAULT '5',
  `description` text,
  `fiscal_year_division_id` int(11) NOT NULL,
  `status` enum('active','inactive','rejected','accepted','delete') NOT NULL DEFAULT 'active',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifier_id` int(11) NOT NULL DEFAULT '0',
  `modify_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `hrm_checkins` */

insert  into `hrm_checkins`(`id`,`user_id`,`reviewed_emp_id`,`emotion`,`rating`,`description`,`fiscal_year_division_id`,`status`,`created`,`modifier_id`,`modify_time`) values (1,1,1,'happy','10','texting checkins',1,'active','2016-03-10 16:04:26',0,'0000-00-00 00:00:00');

/*Table structure for table `hrm_department` */

DROP TABLE IF EXISTS `hrm_department`;

CREATE TABLE `hrm_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(64) NOT NULL DEFAULT 'Gaditek',
  `dept_desc` text,
  `parent_id` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_department` */

/*Table structure for table `hrm_designation` */

DROP TABLE IF EXISTS `hrm_designation`;

CREATE TABLE `hrm_designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation_name` varchar(128) NOT NULL DEFAULT '0',
  `designation_code` varchar(16) NOT NULL DEFAULT '0',
  `status` enum('active','inactive','deleted','suspended') NOT NULL DEFAULT 'inactive',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `hrm_designation` */

/*Table structure for table `hrm_idea_board` */

DROP TABLE IF EXISTS `hrm_idea_board`;

CREATE TABLE `hrm_idea_board` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `idea_title` text NOT NULL,
  `idea_desc` text NOT NULL,
  `idea_department` int(11) NOT NULL,
  `total_votes_up` int(4) NOT NULL DEFAULT '0',
  `total_votes_down` int(4) NOT NULL DEFAULT '0',
  `total_volunteer` int(4) NOT NULL DEFAULT '0',
  `is_publish` tinyint(1) NOT NULL DEFAULT '0',
  `end_date` datetime NOT NULL,
  `status` enum('active','inactive','rejected','deleted','accepted','ended') NOT NULL DEFAULT 'inactive',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_idea_board` */

/*Table structure for table `hrm_idea_board_volunteer` */

DROP TABLE IF EXISTS `hrm_idea_board_volunteer`;

CREATE TABLE `hrm_idea_board_volunteer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `idea_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_idea_board_volunteer` */

/*Table structure for table `hrm_idea_board_votes` */

DROP TABLE IF EXISTS `hrm_idea_board_votes`;

CREATE TABLE `hrm_idea_board_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `idea_id` int(11) NOT NULL,
  `vote_up` tinyint(1) NOT NULL DEFAULT '1',
  `vote_down` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_idea_board_votes` */

/*Table structure for table `hrm_job` */

DROP TABLE IF EXISTS `hrm_job`;

CREATE TABLE `hrm_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_title` varchar(128) NOT NULL,
  `job_description` text,
  `no_of_positions` int(3) NOT NULL DEFAULT '1',
  `hiring_department` int(11) NOT NULL,
  `is_publish` tinyint(1) NOT NULL DEFAULT '0',
  `keywords` text,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_job` */

/*Table structure for table `hrm_job_referral` */

DROP TABLE IF EXISTS `hrm_job_referral`;

CREATE TABLE `hrm_job_referral` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `referral_email` varchar(256) NOT NULL,
  `referral_message` text NOT NULL,
  `referral_status` enum('accept','rejected','pending') NOT NULL DEFAULT 'accept',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_job_referral` */

/*Table structure for table `hrm_payslips_history` */

DROP TABLE IF EXISTS `hrm_payslips_history`;

CREATE TABLE `hrm_payslips_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `emp_code` varchar(16) NOT NULL DEFAULT '000000',
  `emp_name` varchar(128) NOT NULL DEFAULT 'Employee Name',
  `designation` varchar(128) NOT NULL DEFAULT 'Employee',
  `mode_of_payment` enum('cash','bank','cheque') NOT NULL DEFAULT 'bank',
  `pay_basic_salary` varchar(11) NOT NULL DEFAULT '0',
  `pay_mdeical` varchar(9) NOT NULL DEFAULT '0',
  `pay_house_rent` varchar(9) NOT NULL DEFAULT '0',
  `pay_utilities` varchar(9) NOT NULL DEFAULT '0',
  `pay_bonus` varchar(9) NOT NULL DEFAULT '0',
  `pay_over_time` varchar(9) NOT NULL DEFAULT '0',
  `pay_arrears` varchar(9) NOT NULL DEFAULT '0',
  `pay_leave_encashment` varchar(9) NOT NULL DEFAULT '0',
  `pay_other_allowance` varchar(9) NOT NULL DEFAULT '0',
  `pay_total_addition` varchar(11) NOT NULL DEFAULT '0',
  `absences` tinyint(2) NOT NULL DEFAULT '0',
  `deduct_income_tax` varchar(9) NOT NULL DEFAULT '0',
  `deduct_advance_loan` varchar(9) NOT NULL DEFAULT '0',
  `deduct_others` varchar(9) NOT NULL DEFAULT '0',
  `deduct_total` varchar(11) NOT NULL DEFAULT '0',
  `net_payment` varchar(11) NOT NULL DEFAULT '0',
  `leaves_casual` tinyint(2) NOT NULL DEFAULT '0',
  `leaves_sick` tinyint(2) NOT NULL DEFAULT '0',
  `leaves_earned` tinyint(2) NOT NULL DEFAULT '0',
  `absent` tinyint(2) NOT NULL DEFAULT '0',
  `over_time_days` double(2,2) NOT NULL DEFAULT '0.00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_payslips_history` */

/*Table structure for table `hrm_referral_candidate` */

DROP TABLE IF EXISTS `hrm_referral_candidate`;

CREATE TABLE `hrm_referral_candidate` (
  `user_id` int(11) NOT NULL,
  `referral_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_referral_candidate` */

/*Table structure for table `hrm_targets` */

DROP TABLE IF EXISTS `hrm_targets`;

CREATE TABLE `hrm_targets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `targeted_emp_id` int(11) NOT NULL,
  `targets` text NOT NULL,
  `description` text,
  `year_division_id` int(11) NOT NULL,
  `status` enum('active','inactive','rejected','accepted','delete') NOT NULL DEFAULT 'active',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifier_id` int(11) NOT NULL DEFAULT '0',
  `modify_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hrm_targets` */

/*Table structure for table `hrm_user_loged_detail` */

DROP TABLE IF EXISTS `hrm_user_loged_detail`;

CREATE TABLE `hrm_user_loged_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `session_id` varchar(32) NOT NULL DEFAULT '0',
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logout_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `city` varchar(32) NOT NULL DEFAULT 'Karachi',
  `country` varchar(32) NOT NULL DEFAULT 'Pakistan',
  `ip_address` varchar(16) NOT NULL DEFAULT '127.0.0.1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `hrm_user_loged_detail` */

insert  into `hrm_user_loged_detail`(`id`,`user_id`,`session_id`,`login_time`,`logout_time`,`city`,`country`,`ip_address`) values (1,1,'35360dadd6f9dd37ceae3c32495dc4bb','2016-03-08 16:08:01','2016-03-08 12:41:32','','',''),(2,1,'35360dadd6f9dd37ceae3c32495dc4bb','2016-03-08 16:08:44','2016-03-08 12:41:32','','',''),(3,1,'9f1f1dea3d1a7c68101e80ba165cece9','2016-03-08 16:41:22','2016-03-08 12:46:30','','',''),(4,1,'ad8db2eb59b07653a9603fcf698ca682','2016-03-08 16:46:36','2016-03-08 12:47:11','','',''),(5,1,'118e7ce981b4b8079778f4c5127d168d','2016-03-10 10:48:13','2016-03-10 06:48:17','','',''),(6,1,'12d649408242190d3aa886f0ab7e0c4a','2016-03-10 16:03:28','2016-03-10 03:28:44','','',''),(7,1,'c0c440938ad1fedbb6ee80082397ce2b','2016-03-10 19:28:47','0000-00-00 00:00:00','','','');

/*Table structure for table `hrm_user_timelog` */

DROP TABLE IF EXISTS `hrm_user_timelog`;

CREATE TABLE `hrm_user_timelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `location_id` int(11) NOT NULL DEFAULT '0',
  `time_in` datetime NOT NULL,
  `time_out` datetime NOT NULL,
  `on_leave` enum('yes','no','half') NOT NULL DEFAULT 'no',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('active','inactive','delete') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `hrm_user_timelog` */

insert  into `hrm_user_timelog`(`id`,`user_id`,`location_id`,`time_in`,`time_out`,`on_leave`,`created_on`,`status`) values (1,1,7,'2015-11-17 09:00:13','2015-11-17 18:00:02','no','2015-11-17 12:21:35','active'),(2,1,7,'2015-11-17 09:00:12','0000-00-00 00:00:00','no','2015-11-17 17:38:06','active');

/*Table structure for table `hrm_users` */

DROP TABLE IF EXISTS `hrm_users`;

CREATE TABLE `hrm_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_code` varchar(16) NOT NULL DEFAULT '000000',
  `first_name` varchar(64) NOT NULL DEFAULT '0',
  `last_name` varchar(64) NOT NULL DEFAULT '0',
  `designation_id` int(11) NOT NULL DEFAULT '0',
  `department_id` int(11) NOT NULL DEFAULT '0',
  `birthday` date NOT NULL,
  `gender` enum('male','female') NOT NULL DEFAULT 'male',
  `marital_status` enum('single','married') NOT NULL DEFAULT 'single',
  `ntn_num` varchar(9) NOT NULL DEFAULT '0000000-0',
  `nic_num` varchar(16) NOT NULL DEFAULT '00000-0000000-0',
  `nic_num_exp_date` date NOT NULL,
  `job_status` enum('trail','unsatisfied-intrail','contract','contract-not-renewed','parttime','probation','permanent','resigned-company-requested','resigned-self-proposed','notice-period','retired','terminated','termination-unsatisfactory-performance','deceased','physically-disabled-compensated','other') NOT NULL DEFAULT 'permanent',
  `address` text NOT NULL,
  `telephone` varchar(16) DEFAULT NULL,
  `mobile` varchar(16) NOT NULL,
  `work_email` varchar(64) NOT NULL,
  `other_email` varchar(64) NOT NULL,
  `joined_date` date NOT NULL,
  `direct_reporting` int(11) NOT NULL,
  `last_modified` datetime NOT NULL,
  `status` enum('active','inactive','deleted','suspended') NOT NULL DEFAULT 'inactive',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `hrm_users` */

insert  into `hrm_users`(`id`,`emp_code`,`first_name`,`last_name`,`designation_id`,`department_id`,`birthday`,`gender`,`marital_status`,`ntn_num`,`nic_num`,`nic_num_exp_date`,`job_status`,`address`,`telephone`,`mobile`,`work_email`,`other_email`,`joined_date`,`direct_reporting`,`last_modified`,`status`,`created_on`,`created_by`) values (1,'000403','Hammad','Mustafa',0,0,'1988-09-15','male','single','0000000-0','42101-3820026-5','2018-09-15','probation','A-98, St-7 Block N, North Nazimabad, Karachi',NULL,'03222690594','hammad.mustafa@gaditek.com','hammad.mustafa@live.com','2016-02-09',0,'2016-03-08 03:07:49','active','2016-02-09 01:29:19',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
