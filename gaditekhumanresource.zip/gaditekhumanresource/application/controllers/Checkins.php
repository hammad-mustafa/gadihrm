<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Checkins extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('Checkins_model');
    }

    public function insertCheckin()
    {
    	$return 	        =	array('status' => 'error', 'msg' => 'Fields are empty');
        $user_id            =   $this->session->userdata('s_user_id');
        $reviewed_emp_id	=	$this->input->post('reviewed_emp_id');
        $emotion            =   $this->input->post('emotion');
        $rating             =   $this->input->post('rating');
        $description        =   $this->input->post('description');
        $fiscal_year_division_id    =   $this->input->post('fiscal_year_division_id');

        if(empty($user_id))
        {
        	$return['msg'] 	=	'user is not login!';
        }
        elseif(empty($reviewed_emp_id))
        {
        	$return['msg'] 	=	'reviewed_emp_id is empty!';
        }
        elseif(empty($emotion))
        {
            $return['msg']  =   'emotion is empty!';
        }
        elseif(empty($rating))
        {
            $return['msg']  =   'rating is empty!';
        }
        elseif(empty($description))
        {
            $return['msg']  =   'description is empty!';
        }
        elseif(empty($fiscal_year_division_id))
        {
            $return['msg']  =   'fiscal_year_division_id is empty!';
        }
        else
        {
        	$respose 		=	$this->Checkins_model->insertCheckin($user_id,$reviewed_emp_id,$emotion,$rating,$description,$fiscal_year_division_id);
        	
            if($respose=='active')
            {
                $return['status']   =   'success';
                $return['msg']      =   'Insert Successfully';
            }
            else
            {
                $return['status']   =   'error';
                $return['msg']      =   'Sorry! information provided is not correct.';
            }
        }
        echo json_encode($return);
    }

    public function updateCheckin()
    {
        $return             =   array('status' => 'error', 'msg' => 'Fields are empty');
        $user_id            =   $this->session->userdata('s_user_id');
        $checkin_id         =   $this->input->post('checkin_id');
        $status             =   $this->input->post('status');
        
        if(empty($user_id))
        {
            $return['msg']  =   'user is not login!';
        }
        elseif(empty($checkin_id))
        {
            $return['msg']  =   'checkin_id is empty!';
        }
        elseif(empty($status))
        {
            $return['msg']  =   'status is empty!';
        }
        else
        {
            $respose        =   $this->Checkins_model->updateCheckin($user_id,$checkin_id,$status);
            
            if($respose=='active')
            {
                $return['status']   =   'success';
                $return['msg']      =   'Updated Successfully';
            }
            else
            {
                $return['status']   =   'error';
                $return['msg']      =   'Sorry! information provided is not correct.';
            }
        }
        echo json_encode($return);
    }

    public function fetchAllCheckins()
    {
        $respose            =   array('status' => 'error', 'msg' => 'error: user_id must have a value');
        $user_id            =   $this->session->userdata('s_user_id');
        $fetch_status       =   $this->input->post('fetch_status');

        if(empty($user_id))
        {
            $return['msg']  =   'user is not login!';
        }
        elseif(empty($fetch_status))
        {
            $respose['msg'] =   'fetch_status is empty!';
        }
        else
        {
            $respose        =   $this->Checkins_model->fetchAllCheckins($fetch_status);
        }

        echo json_encode($respose);
    }

    public function fetchEmployeeList()
    {
        $respose            =   array('status' => 'error', 'msg' => 'error: user_id must have a value');
        $user_id            =   $this->session->userdata('s_user_id');

        if(empty($user_id))
        {
            $return['msg']  =   'user is not login!';
        }
        else
        {
            $respose        =   $this->Checkins_model->fetchEmployeeList($user_id);
        }

        echo json_encode($respose);
    }

}