<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Userlogin extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('Userlogin_model');
    }

    public function verifyLogin()
    {
    	$return 	=	array('status' => 'error', 'msg' => 'Fields are empty');
    	$username	=	$this->input->post('username');
        $password	=	$this->input->post('password');
        $iplocation =   $this->input->post('iplocation');

        if(empty($username))
        {
        	$return['msg'] 	=	'username is empty!';
        }
        elseif(empty($password))
        {
        	$return['msg'] 	=	'password is empty!';
        }
        else
        {
        	$respose 		=	$this->Userlogin_model->loginUser($username,$password,$iplocation);
        	
            if($respose=='active')
            {
                $return['status']   =   'success';
                $return['msg']      =   'Login Successfully';
            }
            elseif($respose == 'suspended')
            {
                $return['status']   =   'error';
                $return['msg']      =   'Sorry! Your account is suspended by Administrator';
            }
            elseif($respose == 'deleted')
            {
                $return['status']   =   'error';
                $return['msg']      =   'Sorry! Your account is deleted, Please contact administrator to reactivate your account.';
            }
            elseif($respose == 'inactive')
            {
                $return['status']   =   'error';
                $return['msg']      =   'Sorry! Your account is Inactive by Administrator';
            }
            else
            {
                $return['status']   =   'error';
                $return['msg']      =   'Sorry! username or password do not match.';
            }
        }
        echo json_encode($return);
    }

    public function verifyLogout()
    {
        $return     =   array('status' => 'error', 'msg' => 'error: user_id must have a value');
        $user_id    =   $this->input->post('user_id');

        if(!empty($user_id))
        {
            $respose=   $this->Userlogin_model->logoutUser($user_id);
            if($respose > 0)
            {
                $return['status']   =   'success';
                $return['msg']      =   'You are logout';
            }            
        }

        echo json_encode($return);
    }

    public function forgetPassword()
    {
        $return         =   array('status' => 'error', 'msg' => 'error: username must have a value');
        $username      =   $this->input->post('username');

        if(empty($username))
        {
            $return['msg']  =   'username is empty!';
        }
        else
        {
            $respose=   $this->Userlogin_model->forgetPasswordUser($username);
            if($respose > 0)
            {
                $return['status']   =   'success';
                $return['msg']      =   'Your password is sent at your email address';
            }
            else
            {
                $return['status']   =   'error';
                $return['msg']      =   'Sorry! username or password do not match.';
            }
        }

        echo json_encode($return);
    }    
}