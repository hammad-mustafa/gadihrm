<div id="mobile-menu">
  <div class="container">
    <ul>
      <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-456"><a title="NetSol Technologies | Company" href="http://netsolbeta.com/about-us/">Company</a>
        <ul class="sub-menu">
          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-33"><a title="NetSol Technologies | About Us" href="about-us/">About Us</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-36"><a title="NetSol Technologies | Board Of Directors" href="our-team/#section-bod">Board Of Directors</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2075"><a title="NetSol Technologies | Management Team" href="our-team/#section-mt">Management Team</a></li>
          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2278"><a href="corporate-social-responsibility/">Corporate Social Responsibility</a></li>
        </ul>
      </li>
      <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2076"><a title="NetSol Technologies | Products" href="#">Products</a>
        <ul class="sub-menu">
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2077"><a title="NetSol Technologies | NFS Ascent" href="products/#nfsascent">NFS Ascent</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2078"><a title="NetSol Technologies | NFS Mobility" href="products/#nfsmobility">NFS Mobility</a></li>
        </ul>
      </li>
      <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2079"><a title="NetSol Technologies | Services" href="#">Consultancy</a>
        <ul class="sub-menu">
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2080"><a title="NetSol Technologies | Business Consultancy" href="consultancy/#Business-Consultancy">Business Consultancy</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2081"><a title="NetSol Technologies | Information Security Services" href="consultancy/#Information-security">Information Security Services</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2082"><a title="NetSol Technologies | Independent System Review" href="consultancy/#Independent-System-Review">Independent System Review</a></li>
        </ul>
      </li>
      <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2083"><a href="#">Investors</a>
        <ul class="sub-menu">
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2084"><a href="http://ir.stockpr.com/netsoltech/">Overview</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2085"><a href="http://ir.stockpr.com/netsoltech/press-releases">News / IR Events</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2086"><a href="http://ir.stockpr.com/netsoltech/profile">Company Information</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2087"><a href="http://ir.stockpr.com/netsoltech/financials">Financial Information</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2088"><a href="http://ir.stockpr.com/netsoltech/quote">Stock Data</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2089"><a href="http://ir.stockpr.com/netsoltech/all-sec-filings">SEC Filings</a></li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2090"><a href="http://ir.stockpr.com/netsoltech/board-of-directors">Corporate Governance</a></li>
        </ul>
      </li>
      <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2091"><a href="#">Get in Touch</a>
        <ul class="sub-menu">
          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2092"><a href="contact-us/">Contact Us</a></li>
        </ul>
      </li>
      <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2094"><a href="#">Resource Center</a>
        <ul class="sub-menu">
          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2096"><a href="resource-center/articles/">Articles</a></li>
          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2095"><a href="downloads/">Downloads</a></li>
          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2093"><a href="event-listings/">Event listings</a></li>
        </ul>
      </li>
      <li id="mobile-search">  
        <form action="http://www.netsoltech.com" method="GET">
              <input type="text" name="s" value="" placeholder="Search.." />
        </form> 
      </li>   
    </ul>
  </div>
</div>