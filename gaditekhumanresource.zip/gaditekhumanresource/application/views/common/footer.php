<div id="footer-outer">
	<!-- Footer Loader-->
	<div id="footer-widgets">
		<div class="container">
			<div class="row">
				<div class="col span_3 one-fourths clear-both">
			      	<!-- Footer widget area 1 -->
				    <div class="widget widget_text" id="text-7"><h4>NetSol Technologies Inc.</h4>

					<div class="textwidget"><a title="" href="<?php echo site_url('about') ?>">About Us</a><br>
						<hr>
						<a title="" href="<?php echo site_url('our-team#section-bod') ?>">Board Of Directors</a><br>
						<hr>
						<a title="" href="<?php echo site_url('our-team#section-mt') ?>">Management Team</a><br>
						<hr>
						<a title="" href="<?php echo site_url('about#testimonial') ?>">Testimonials</a></div>
					</div>
				</div><!--/span_3-->
				<div class="col span_3 one-fourths right-edge">
					<!-- Footer widget area 2 -->
			        <div class="widget widget_text" id="text-9">
			        	<h4>Investors</h4>
			        	<div class="textwidget">
			        		<a title="" href="http://ir.stockpr.com/netsoltech/press-releases">News / Events</a>
			        		<br>
							<hr>
							<a title="" href="http://ir.stockpr.com/netsoltech/all-sec-filings">SEC Filings</a>
							<br>
							<hr>
							<a title="" href="http://ir.stockpr.com/netsoltech/financials">Financial Information</a>
							<br>
							<hr>
							<a title="" href="http://ir.stockpr.com/netsoltech/">More</a>
						</div>
					</div>
				</div><!--/span_3-->
				<div class="col span_3 one-fourths clear-both">
				 	<!-- Footer widget area 3 -->
				    <div class="widget widget_text" id="text-10">
				    	<h4>Information</h4>
				        <div class="textwidget">
				        	<a title="" href="#/">Sitemap</a>
							<hr>
							<a title="" href="<?php echo site_url('website-term-of-use') ?>">Terms of Use</a><br>
							<hr>
							<a title="" href="<?php echo site_url('privacy-policy') ?>">Privacy Policy</a><br>
							<hr>
							<a title="" href="<?php echo site_url('contact-us') ?>">Contact Us</a><br>
						</div>
					</div>
				</div><!--/span_3-->
				<div class="col span_3 one-fourths right-edge col_last">
					<!-- Footer widget area 4 -->
				    <div class="widget widget_text" id="text-3">
				    	<h4>Upcoming Events</h4>
				    	<div class="textwidget">
				    		<a target="_blank" title="" href="<?php echo site_url('event-listing') ?>">FLA Annual Dinner 2015</a><br>
							<hr>
							<a target="_blank" title="" href="<?php echo site_url('event-listing') ?>">Synergize User Conference </a><br>
							<hr>
							<a target="_blank" title="" href="<?php echo site_url('event-listing') ?>">AFI Automotive Conference </a><br>
							<hr>
							<a title="" href="<?php echo site_url('event-listing') ?>">More</a>
						</div>
					</div>
				</div><!--/span_3-->
			</div><!--/row-->
		</div><!--/container-->
	</div><!--/footer-widgets-->

	<div class="row" id="copyright">
		<div class="container">
			<div class="col span_5">
				<p>&copy; 2015 NetSol Technologies.</p>
			</div><!--/span_5-->
			<div class="col span_7 col_last">
				<ul id="social">
				</ul>
			</div><!--/span_7-->
		</div><!--/container-->
	</div><!--/row-->
    <div style="height:5px; width:100%; float:left; background:#000;">
        <div style="float:left; width:25%; height:5px; background:#BDD7EE;"></div>
        <div style="float:left; width:25%; height:5px; background:#9DC2E5;"></div>
        <div style="float:left; width:25%; height:5px; background:#1970B8;"></div>
        <div style="float:left; width:25%; height:5px; background:#1D4E79;"></div>
    </div>
</div><!--/footer-outer-->