<header id="top">
    <div class="container">
      <div class="row">
        <div class="col span_3">
          <a id="logo" href="http://www.netsoltech.com" >
            <img class="" alt="NetSol Technologies" src="<?php echo base_url() ?>assets/images/uploads/2015/01/netsologo71.png" /> 
          </a>
        </div><!--/span_3-->
        <div class="col span_9 col_last">
          <a href="#" id="toggle-nav"><i class="icon-reorder"></i></a>                  
          <nav>
            <ul class="sf-menu">
              <li id="menu-item-456" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sf-with-ul menu-item-456"><a title="NetSol Technologies | Company" href="<?php echo site_url('about') ?>">Company<span class="sf-sub-indicator"><i class="icon-angle-down"></i></span></a>
                <ul class="sub-menu">
                  <li id="menu-item-33" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-33"><a title="NetSol Technologies | About Us" href="<?php echo site_url('about') ?>">About Us</a></li>
                  <li id="menu-item-36" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-36"><a title="NetSol Technologies | Board Of Directors" href="<?php echo site_url('our-team#section-bod') ?>">Board Of Directors</a></li>
                  <li id="menu-item-2075" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2075"><a title="NetSol Technologies | Management Team" href="<?php echo site_url('our-team#section-mt') ?>">Management Team</a></li>
                  <li id="menu-item-2278" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2278"><a href="<?php echo site_url('corporate-social-responsibility') ?>">Corporate Social Responsibility</a></li>
                </ul>
              </li>
              <li id="menu-item-2076" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sf-with-ul menu-item-2076"><a title="NetSol Technologies | Products" href="<?php echo site_url('products') ?>">Products<span class="sf-sub-indicator"><i class="icon-angle-down"></i></span></a>
                <ul class="sub-menu">
                  <li id="menu-item-2077" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2077"><a title="NetSol Technologies | NFS Ascent" href="<?php echo site_url('products#nfsascent') ?>">NFS Ascent</a></li>
                  <li id="menu-item-2078" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2078"><a title="NetSol Technologies | NFS Mobility" href="<?php echo site_url('products#nfsmobility') ?>">NFS Mobility</a></li>
                </ul>
              </li>
              <li id="menu-item-2079" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sf-with-ul menu-item-2079"><a title="NetSol Technologies | Services" href="<?php echo site_url('consultancy') ?>">Consultancy <span class="sf-sub-indicator"><i class="icon-angle-down"></i></span></a>
                <ul class="sub-menu">
                  <li id="menu-item-2080" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2080"><a title="NetSol Technologies | Business Consultancy" href="<?php echo site_url('consultancy#Business-Consultancy') ?>">Business Consultancy</a></li>
                  <li id="menu-item-2081" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2081"><a title="NetSol Technologies | Information Security Services" href="<?php echo site_url('consultancy#Information-security') ?>">Information Security Services</a></li>
                  <li id="menu-item-2082" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2082"><a title="NetSol Technologies | Independent System Review" href="<?php echo site_url('consultancy#Independent-System-Review') ?>">Independent System Review</a></li>
                </ul>
              </li>
              <li id="menu-item-2083" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sf-with-ul menu-item-2083"><a href="#">Investors<span class="sf-sub-indicator"><i class="icon-angle-down"></i></span></a>
                <ul class="sub-menu">
                  <li id="menu-item-2084" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2084"><a href="http://ir.stockpr.com/netsoltech/">Overview</a></li>
                  <li id="menu-item-2085" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2085"><a href="http://ir.stockpr.com/netsoltech/press-releases">News / IR Events</a></li>
                  <li id="menu-item-2086" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2086"><a href="http://ir.stockpr.com/netsoltech/profile">Company Information</a></li>
                  <li id="menu-item-2087" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2087"><a href="http://ir.stockpr.com/netsoltech/financials">Financial Information</a></li>
                  <li id="menu-item-2088" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2088"><a href="http://ir.stockpr.com/netsoltech/quote">Stock Data</a></li>
                  <li id="menu-item-2089" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2089"><a href="http://ir.stockpr.com/netsoltech/all-sec-filings">SEC Filings</a></li>
                  <li id="menu-item-2090" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2090"><a href="http://ir.stockpr.com/netsoltech/board-of-directors">Corporate Governance</a></li>
                </ul>
              </li>
              <li id="menu-item-2091" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sf-with-ul menu-item-2091"><a href="<?php echo site_url('contact-us') ?>">Get in Touch<span class="sf-sub-indicator"><i class="icon-angle-down"></i></span></a>
                <ul class="sub-menu">
                  <li id="menu-item-2092" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2092"><a href="<?php echo site_url('contact-us') ?>">Contact Us</a></li>
                </ul>
              </li>
              <li id="menu-item-2094" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sf-with-ul menu-item-2094"><a href="#">Resource Center<span class="sf-sub-indicator"><i class="icon-angle-down"></i></span></a>
                <ul class="sub-menu">
                  <li id="menu-item-2096" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2096"><a href="<?php echo site_url('articles') ?>">Articles</a></li>
                  <li id="menu-item-2095" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2095"><a href="<?php echo site_url('downloads') ?>">Downloads</a></li>
                  <li id="menu-item-2093" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2093"><a href="<?php echo site_url('event-listing') ?>">Event listings</a></li>
                </ul>
              </li>
              <li id="search-btn">
                <div><a href=""><span class="icon-salient-search" aria-hidden="true"></span></a></div>
              </li>
            </ul>
          </nav>
        </div><!--/span_9-->
      </div><!--/row-->
    </div><!--/container-->
  </header>