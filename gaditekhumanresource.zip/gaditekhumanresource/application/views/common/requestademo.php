<script>
  jQuery(document).ready(function($) {
    $(window).scroll(function() {
      var pos = $(".demofixedbtnarea").position();     
      var windowpos = $(window).scrollTop();
  
      if (windowpos == 0)
      {
        $(".demofixedbtnarea").css('bottom', '16px');
      } 
  
      else if (windowpos >= 250)
      {
        $(".demofixedbtnarea").css('bottom', '58px');
      }
      else
      {
        //$("#side-div").css('background-color', '#6f8cc0'); //blue
      }
    });
  });
</script>

<div class="demofixedbtnarea">
  <div class="demofixedbtn lbp-inline-link-31" onclick="">
    Request <br />Demo
  </div>
</div>

<a id="to-top" style="bottom:13px;">
  <i class="icon-angle-up"></i>
</a>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-62171517-1', 'auto');
  ga('send', 'pageview');
</script>

<a id="scroll-to-top" href="#" title="Scroll to Top">
  Top
</a>
<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?"http":"https";if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document, "script", "twitter-wjs");
</script>
<script type="text/javascript">
  (function() {
    var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;
    po.src = "https://apis.google.com/js/platform.js";
    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
<script src="//platform.linkedin.com/in.js" type="text/javascript">
    lang: en_US
</script>
<script type='text/javascript'>
  /* <![CDATA[ */
  var MyAcSearch = {"url":"http:\/\/www.netsoltech.com\/wp-admin\/admin-ajax.php"};
  /* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/nectar/assets/functions/ajax-search/wpss-search-suggest.js'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
  /* <![CDATA[ */
  var _wpcf7 = {"loaderUrl":"http:\/\/www.netsolbeta.com\/site-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
  /* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>plugins/contact-form-7/includes/js/scripts.js?ver=3.9'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/js/superfish.js?ver=1.4.8'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/js/respond.js?ver=1.1'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/js/nicescroll.js?ver=3.5.4'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/js/sticky.js?ver=1.0'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/js/prettyPhoto.js?ver=4.8.1'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/js/isotope.min.js?ver=2.0'></script>
<script type='text/javascript'>
  /* <![CDATA[ */
  var nectarLove = {"ajaxurl":"http:\/\/www.netsolbeta.com\/wp-admin\/admin-ajax.php","postID":"8","rooturl":"http:\/\/www.netsolbeta.com","pluginPages":[],"disqusComments":"false"};
  /* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/js/init.js?ver=4.8.1'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/js/" ?>comment-reply.min.js?ver=4.0.1'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>themes/salient/wpbakery/js_composer/assets/js/js_composer_front.js?ver=3.7.3'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>plugins/rotatingtweets/js/jquery.cycle.all.min.js?ver=4.0.1'></script>
<script type='text/javascript' src='<?php echo base_url()."assets/site-content/" ?>plugins/rotatingtweets/js/rotating_tweet.js?ver=1.7.2'></script>
</body>
<div style="display: none;">
  <div id="lbp-inline-href-31" style="padding: 10px; background: #fff; color: #000;">
    <div class="wpcf7" id="wpcf7-f495-o2" lang="en-US" dir="ltr">
      <div class="screen-reader-response"></div>
        <form action="/about-us/#wpcf7-f495-o2" method="post" class="wpcf7-form" enctype="multipart/form-data" novalidate="novalidate">
          <div style="display: none;">
            <input type="hidden" name="_wpcf7" value="495" />
            <input type="hidden" name="_wpcf7_version" value="3.9" />
            <input type="hidden" name="_wpcf7_locale" value="en_US" />
            <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f495-o2" />
            <input type="hidden" name="_wpnonce" value="f220268420" />
          </div>
          <h2>Request Demo</h2>
          <p>Please provide the following details and we will get back to you.</p>
          <div class="demofield_row">
            <div class="demofield_n">
              <p>
                <span class="wpcf7-form-control-wrap FullName">
                  <input type="text" id="fullname" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input" aria-required="true" aria-invalid="false" placeholder="Full Name" />
                </span>
              </p>
            </div>
            <div class="demofield_n">
              <p>
                <span class="wpcf7-form-control-wrap Company">
                  <input type="text" id="rfcompany" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input" aria-required="true" aria-invalid="false" placeholder="Company" />
                </span>
              </p>
            </div>
            <div class="demofield_n">
              <p>
                <span class="wpcf7-form-control-wrap Designation">
                  <input type="text" id="rfdesignation" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input" aria-required="true" aria-invalid="false" placeholder="Designation" />
                </span>
              </p>
            </div>
          </div>
          <div class="demofield_row">
            <div class="demofield_n">
              <p>
                <span class="wpcf7-form-control-wrap Email">
                  <input type="email" id="rfemail" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email input" aria-required="true" aria-invalid="false" placeholder="Email" />
                </span>
              </p>
            </div>
            <div class="demofield_n">
              <p>
                <span class="wpcf7-form-control-wrap Country">
                  <select id="rfcountry" class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required input" aria-required="true" aria-invalid="false">
                    <option value="Select Country">Select Country</option>
                    <option value="Afghanistan">Afghanistan</option>
                    <option value="Aland Islands">Aland Islands</option>
                    <option value="Albania">Albania</option>
                    <option value="Algeria">Algeria</option>
                    <option value="American Samoa">American Samoa</option>
                    <option value="Andorra">Andorra</option>
                    <option value="Angola">Angola</option>
                    <option value="Anguilla">Anguilla</option>
                    <option value="Antarctica">Antarctica</option>
                    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                    <option value="Argentina">Argentina</option>
                    <option value="Armenia">Armenia</option>
                    <option value="Aruba">Aruba</option>
                    <option value="Australia">Australia</option>
                    <option value="Austria">Austria</option>
                    <option value="Azerbaijan">Azerbaijan</option>
                    <option value="Bahamas">Bahamas</option>
                    <option value="Bahrain">Bahrain</option>
                    <option value="Bangladesh">Bangladesh</option>
                    <option value="Barbados">Barbados</option>
                    <option value="Belarus">Belarus</option>
                    <option value="Belgium">Belgium</option>
                    <option value="Belize">Belize</option>
                    <option value="Benin">Benin</option>
                    <option value="Bermuda">Bermuda</option>
                    <option value="Bhutan">Bhutan</option>
                    <option value="Bolivia">Bolivia</option>
                    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                    <option value="Botswana">Botswana</option><option value="Bouvet Island">Bouvet Island</option><option value="Brazil">Brazil</option><option value="British Indian Ocean Territory">British Indian Ocean Territory</option><option value="British Virgin Islands">British Virgin Islands</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina Faso">Burkina Faso</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Cayman Islands">Cayman Islands</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Christmas Island">Christmas Island</option><option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Cook Islands">Cook Islands</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Democratic Republic of Congo">Democratic Republic of Congo</option><option value="Denmark">Denmark</option><option value="Disputed Territory Djibouti">Disputed Territory Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Falkland Islands">Falkland Islands</option><option value="Faroe Islands">Faroe Islands</option><option value="Federated States of Micronesia">Federated States of Micronesia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="French Guyana">French Guyana</option><option value="French Polynesia">French Polynesia</option><option value="French Southern Territories">French Southern Territories</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Gibraltar">Gibraltar</option><option value="Greece">Greece</option><option value="Greenland">Greenland</option><option value="Grenada">Grenada</option><option value="Guadeloupe">Guadeloupe</option><option value="Guam">Guam</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option><option value="Honduras">Honduras</option><option value="Hong Kong">Hong Kong</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Iraq-Saudi Arabia Neutral Zone">Iraq-Saudi Arabia Neutral Zone</option><option value="Ireland">Ireland</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Ivory Coast">Ivory Coast</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macau">Macau</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia Maldives">Malaysia Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Martinique">Martinique</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mayotte">Mayotte</option><option value="Mexico">Mexico</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Montserrat">Montserrat</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar">Myanmar</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands Antilles">Netherlands Antilles</option><option value="Netherlands">Netherlands</option><option value="New Caledonia">New Caledonia</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Niue">Niue</option><option value="Norfolk Island">Norfolk Island</option><option value="North Korea">North Korea</option><option value="Northern Mariana Islands">Northern Mariana Islands</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Palestinian Territories">Palestinian Territories</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Pitcairn Islands">Pitcairn Islands</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Reunion">Reunion</option><option value="Romania">Romania</option><option value="Russia">Russia</option><option value="Rwanda">Rwanda</option><option value="Saint Helena and Dependencies">Saint Helena and Dependencies</option><option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option><option value="Saint Lucia">Saint Lucia</option><option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option><option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome and Principe">Sao Tome and Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Georgia and South Sandwich Islands">South Georgia and South Sandwich Islands</option><option value="South Korea">South Korea</option><option value="Spain">Spain</option><option value="Spratly Islands">Spratly Islands</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tokelau">Tokelau</option><option value="Tonga">Tonga</option><option value="Trinidad and Tobago">Trinidad and Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Turks And Caicos Islands">Turks And Caicos Islands</option><option value="Tuvalu">Tuvalu</option><option value="US Virgin Islands">US Virgin Islands</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City">Vatican City</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Wallis and Futuna">Wallis and Futuna</option><option value="Western Sahara">Western Sahara</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option></select>
                </span>
              </p>
            </div>
            <div class="demofield_n">
              <p>
                <span class="wpcf7-form-control-wrap Telephone">
                  <input type="tel" id="rfphone" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel input" aria-required="true" aria-invalid="false" placeholder="Phone" />
                </span>
              </p>
            </div>
          </div>
          
          <div class="demofield_row">
            <div class="demofield_n">
              <p>Request demo for:- 
                <span class="wpcf7-form-control-wrap checkbox-614">
                  <span class="wpcf7-form-control wpcf7-checkbox">
                    <span class="wpcf7-list-item first">
                      <input type="checkbox" id="requestForA" value="NFS Ascent" />
                      &nbsp;
                      <span class="wpcf7-list-item-label">
                        NFS Ascent
                      </span>
                    </span>
                    <span class="wpcf7-list-item last">
                      <input type="checkbox" id="requestForM" value="NFS Mobility" />
                      &nbsp;
                      <span class="wpcf7-list-item-label">
                        NFS Mobility
                      </span>
                    </span>
                  </span>
                </span>
              </p>
            </div>
          </div>
          
          <div class="demofield_row">
            <div class="demofield_n">
              <p>Type of Business:- 
                <span class="wpcf7-form-control-wrap checkbox-614">
                  <span class="wpcf7-form-control wpcf7-checkbox">
                    <span class="wpcf7-list-item first">
                      <input type="checkbox" id="typeofBR" value="Retail" />
                      &nbsp;
                      <span class="wpcf7-list-item-label">
                        Retail
                      </span>
                    </span>

                    <span class="wpcf7-list-item second">
                      <input type="checkbox" id="typeofBW" value="Wholesale" />
                      &nbsp;
                      <span class="wpcf7-list-item-label">
                        Wholesale
                      </span>
                    </span>

                    <span class="wpcf7-list-item last">
                      <input type="checkbox" id="typeofBO" value="Other" />
                      &nbsp;
                      <span class="wpcf7-list-item-label">
                        Other
                      </span>
                    </span>
                    <input type="text" id="typeofBOther" size="40" class="wpcf7-form-control wpcf7-text input" placeholder="Type of Business (If Other)" />

                    <!-- <span class="wpcf7-form-control-wrap other">
                    </span> -->

                  </span>
                </span>
              </p>
            </div>
          </div>

          

          <div class="demofield_row">
            <div class="demofield_n">
              <p>
                Contract Volume/yr:-
                <br />
                <span class="wpcf7-form-control-wrap menu-226">
                  <select id="contractVol" class="wpcf7-form-control wpcf7-select" aria-invalid="false">
                    <option selected value="Less than 10,000">Less than 10,000</option>
                    <option value="10,000-40,000">10,000-40,000</option>
                    <option value="40,000-70,000">40,000-70,000</option>
                    <option value="70,000-100,000">70,000-100,000</option>
                    <option value="Greater than 100,000">Greater than 100,000</option>
                  </select>
                </span>
              </p>
              <p>
                Types of Leases:- 
                <span class="wpcf7-form-control-wrap TypesofLeases">
                  <span class="wpcf7-form-control wpcf7-checkbox wpcf7-validates-as-required">
                    <span class="wpcf7-list-item first">
                      <label>
                        <input type="checkbox" id="typeofLFL" value="Financial Lease" />
                        &nbsp;
                        <span class="wpcf7-list-item-label">
                          Financial Lease
                        </span>
                      </label>
                    </span>
                    <span class="wpcf7-list-item">
                      <label>
                        <input type="checkbox" id="typeofLOL" value="Operating Lease" />
                        &nbsp;
                        <span class="wpcf7-list-item-label">
                          Operating Lease
                        </span>
                      </label>
                    </span>
                    <span class="wpcf7-list-item">
                      <label>
                        <input type="checkbox" id="typeofLHP" value="Hire Purchase" />
                        &nbsp;
                        <span class="wpcf7-list-item-label">
                          Hire Purchase
                        </span>
                      </label>
                    </span>
                    <span class="wpcf7-list-item last">
                      <label>
                        <input type="checkbox" id="typeofLO" value="Other" />
                        &nbsp;
                        <span class="wpcf7-list-item-label">
                          Other
                        </span>
                      </label>
                    </span>

                    <input type="text" id="typeofLOther" size="40" class="wpcf7-form-control wpcf7-text input" placeholder="Type of Leases (If Other)" />
                  </span>
                </span>
                <!-- <span class="wpcf7-form-control-wrap blank">
                  <input type="text" id="typeofLOther" size="40" class="wpcf7-form-control wpcf7-text input" placeholder="Type of Leases (If Other)" />
                </span> -->
              </p>
              <p>
                Type of Organization:- 
                <br>
                <span class="wpcf7-form-control-wrap TypeofOrganization">
                  <select id="typeofO" class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required customselect" aria-required="true" aria-invalid="false">
                    <option selected value="Auto Captive">Auto Captive</option>
                    <option value="Bank or subsidiary">Bank or subsidiary</option>
                    <option value="Broker - Packager - Discounter">Broker - Packager - Discounter</option>
                    <option value="Big Ticket">Big Ticket</option>
                    <option value="Credit Union">Credit Union</option>
                    <option value="Equipment Leasing">Equipment Leasing</option>
                    <option value="General Leasing">General Leasing</option>
                    <option value="Independent">Independent</option>
                    <option value="Other">Other</option>
                  </select>
                </span>
                <span class="wpcf7-form-control-wrap blank">
                  <input type="text" id="typeofOOther" size="40" class="wpcf7-form-control wpcf7-text input" aria-invalid="false" placeholder="Type of Organization (If Other)" />
                </span>
              </p>
            </div>
          </div>
          <div class="demofield_row">
            <div class="demofield_n">
              <p>
                Comments:- 
                <br>
                <span class="wpcf7-form-control-wrap textarea-762">
                  <textarea id="commentsSection" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea>
                </span>
              </p>
            </div>
          </div>
          <div class="demofield_row">
            <div class="demofield_n">
              <p>
                Upload RFP/RFS:- 
                <span class="wpcf7-form-control-wrap file-81">
                  <input type="file" id="RFPs" value="1" size="40" class="wpcf7-form-control wpcf7-file" aria-invalid="false" />
                </span>
              </p>
            </div>
          </div>
          <p>
            <input type="button" id="requestfordemo" value="Send" class="wpcf7-form-control wpcf7-submit" style="background-color: #71a4f9; padding: 10px 15px; border: #91B8F7 solid 2px; width: 130px !important; color: #fff; cursor: pointer; text-transform: uppercase; font-size: 13px; -webkit-border-radius: 2px; float:left;" />
            <span id="requestFormloaderGif" style="display:none; float:left; position: relative;">
              <img src="<?php echo base_url()."assets/images/"?>ajax_loader_blue_32.gif">
            </span>
            <span id="requestFormReturnMessage" style="float: left; position: relative; left: 10px; display:none;"></span>
          </p>
          <style>
            p{color:#333;}
          </style>
          <div class="wpcf7-response-output wpcf7-display-none">
          </div>
          <input type="hidden" id="iplocation" />
        </form>
      </div>
    </div>
</div>

<script src="<?php echo base_url().'assets/' ?>site-content/themes/salient-child/js/jquery.simplePopup.js" type="text/javascript"></script>
<script type="text/javascript">
jQuery(document).ready(function ($)
{
  $.get(("https:"==document.location.protocol?"https://":"http://")+"api.ipinfodb.com/v3/ip-city/?key=cbc9931567126550892a1c603b1d2862366da26633975621b58dbc32a8b87711&format=json&callback=?",function(e)
  {
    $('#iplocation').val(JSON.stringify(e));
  },"json");

  $("#requestfordemo").click(function ()
  {
    $("#fullname").css('border-color','');
    $("#rfemail").css('border-color','');
    $("#rfphone").css('border-color','');
    $("#requestFormloaderGif").show();

    var fullname    =   $("#fullname").val();
    var company     =   $("#rfcompany").val();
    var designation =   $("#rfdesignation").val();
    var email       =   $("#rfemail").val();
    var country     =   $("#rfcountry").val();
    var phone       =   $("#rfphone").val();
    
    var requestFor;
    
    var typeofBOther=   $("#typeofBOther").val();
    var typeofB;

    var contractVol =   $("#contractVol").val();

    var typeofLOther=   $("#typeofLOther").val();
    var typeofL;

    var typeofO     =   $("#typeofO").val();
    var typeofOOther=   $("#typeofOOther").val();

    var comments    =   $("#commentsSection").val();
    var RFPs        =   $("#RFPs").val();


    //For Normal Validations
    if(!validateAddress(fullname))
    {
      $("#fullname").css('border-color','red');
      $("#requestFormReturnMessage").show();
      $('#requestFormReturnMessage').html('Name you enter is Invalid');
      $("#requestFormloaderGif").hide();
      return false;
    }
    else if(!validateEmail(email))
    {
      $("#rfemail").css('border-color','red');
      $("#requestFormReturnMessage").show();
      $('#requestFormReturnMessage').html('Email you enter is Invalid');
      $("#requestFormloaderGif").hide();
      return false;
    }
    else if(!validateNumber(phone))
    {
      $("#rfphone").css('border-color','red');
      $("#requestFormReturnMessage").show();
      $('#requestFormReturnMessage').html('Phone number you enter is Invalid');
      $("#requestFormloaderGif").hide();
      return false;
    }

    
    //For Request of Demo Value
    if($("#requestForA").is(':checked') && $("#requestForM").is(':checked'))
    {
      requestFor  =   'Both';
    }
    else if(!$("#requestForA").is(':checked') && $("#requestForM").is(':checked'))
    {
      requestFor  =   'NFS Mobility';
    }
    else if($("#requestForA").is(':checked') && !$("#requestForM").is(':checked'))
    {
      requestFor  =   'NFS Ascent';
    }
    else
    {
      requestFor  =   'Both'; 
    }


    //For Type of Business
    if($("#typeofBR").is(':checked') && !$("#typeofBW").is(':checked') && !$("#typeofBO").is(':checked'))
    {
      typeofB  =   'Retail';
    }
    else if(!$("#typeofBR").is(':checked') && $("#typeofBW").is(':checked') && !$("#typeofBO").is(':checked'))
    {
      typeofB  =   'Wholesale';
    }
    else if(!$("#typeofBR").is(':checked') && !$("#typeofBW").is(':checked') && $("#typeofBO").is(':checked'))
    {
      typeofB  =   'Other';
    }
    else
    {
      typeofB  =   'All'; 
    }
    
    
    //For Type of Leases
    if($("#typeofLFL").is(':checked') && !$("#typeofLOL").is(':checked') && !$("#typeofLHP").is(':checked') && !$("#typeofLO").is(':checked'))
    {
      typeofL  =   'Financial Lease';
    }
    else if(!$("#typeofLFL").is(':checked') && $("#typeofLOL").is(':checked') && !$("#typeofLHP").is(':checked') && !$("#typeofLO").is(':checked'))
    {
      typeofL  =   'Operating Lease';
    }
    else if(!$("#typeofLFL").is(':checked') && !$("#typeofLOL").is(':checked') && $("#typeofLHP").is(':checked') && !$("#typeofLO").is(':checked'))
    {
      typeofL  =   'Hire Purchase';
    }
    else if(!$("#typeofLFL").is(':checked') && !$("#typeofLOL").is(':checked') && !$("#typeofLHP").is(':checked') && $("#typeofLO").is(':checked'))
    {
      typeofL  =   'Other';
    }
    else
    {
      typeofL  =   'All'; 
    }

    //For Setting the value
    $.post("<?php echo base_url();?>Requestform/insertdata/",{fullname:fullname,company:company,designation:designation,email:email,country:country,phone:phone,requestFor:requestFor,typeofB:typeofB,typeofBOther:typeofBOther,contractVol:contractVol,typeofLOther:typeofLOther,typeofL:typeofL,typeofO:typeofO,typeofOOther:typeofOOther,comments:comments,RFPs:RFPs,iplocation:$("#iplocation").val()},function(e)
    {
      $("#requestFormloaderGif").hide();
      $("#requestFormReturnMessage").show();
      $('#requestFormReturnMessage').html(e.msg);

      //Reset All
      $("#fullname").val('');
      $("#rfcompany").val('');
      $("#rfdesignation").val('');
      $("#rfemail").val('');
      $("#rfcountry").val('');
      $("#rfphone").val('');
      $("#requestForA").attr('checked', false);
      $("#requestForM").attr('checked', false);
      $("#typeofBR").attr('checked', false);
      $("#typeofBW").attr('checked', false);
      $("#typeofBO").attr('checked', false);
      $("#typeofBOther").val('');
      $("#contractVol").val('');
      $("#typeofLFL").attr('checked', false);
      $("#typeofLOL").attr('checked', false);
      $("#typeofLHP").attr('checked', false);
      $("#typeofLO").attr('checked', false);
      $("#typeofLOther").val('');
      $("#typeofO").val('');
      $("#typeofOOther").val('');
      $("#commentsSection").val('');
      $("#RFPs").val('');
    },"json");
  });
});


function validateAddress(n)
{
  if( /[^a-zA-Z0-9\s\-\/]/.test(n) ) // /^[a-zA-Z\séåü]+$/
  {
    return false;
  }
  return true;
}

function validateNumber(n)
{
  if( /[^0-9\s\-\/]/.test(n) ) // /^[a-zA-Z\séåü]+$/
  {
    return false;
  }
  return true;
}

function validateEmail(email)
{
  var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
  return re.test(email);
}
</script>
</html>