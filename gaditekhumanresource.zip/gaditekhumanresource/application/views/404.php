<?php require('api/config.php'); ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ShowBizy</title>
<?php include_once("inc/js.php"); ?>
<script>
$(window).load(function(){
	
	// We are listening for the window load event instead of the regular document ready.
	
	function animSteam(){
		
		// Create a new span with the steam1, or steam2 class:
		
		$('<span>',{
			className:'steam'+Math.floor(Math.random()*2 + 1),
			css:{
				// Apply a random offset from 10px to the left to 10px to the right
				marginLeft	: -10 + Math.floor(Math.random()*20)
			}
		}).appendTo('#rocket').animate({
			left:'-=58',
			bottom:'-=100'
		}, 120,function(){
			
			// When the animation completes, remove the span and
			// set the function to be run again in 10 milliseconds
			
			$(this).remove();
			setTimeout(animSteam,10);
		});
	}
	
	function moveRocket(){
		$('#rocket').animate({'left':'+=100'},5000).delay(1000)
					.animate({'left':'-=100'},5000,function(){
				setTimeout(moveRocket,1000);
		});
	}

	// Run the functions when the document and all images have been loaded.
		
	moveRocket();
	animSteam();
});

</script>
<style>
#rocket{
 width:491px;
 height:250px;
 background: url('images/rocket.png') no-repeat;
 margin:140px auto 10px;
 position:relative;
}
.bd{

 background:url('images/lightset.jpg') no-repeat center center #1d1d1d;
 color:#eee;
  background-size:100%;
 
}
.text-page{color: #fff;
    font: 16px 'proxima_novasemibold',Arial;
    margin-top:15px; margin-left:25px;}
.hgroup{

	

	display:block;
	margin:-13px auto;
	width:850px;
	font-family:'Century Gothic',Calibri,'Myriad Pro',Arial,Helvetica,sans-serif;
	text-align:center; background-color: rgba(255, 255, 255, 0.5) !important; border-radius:10px; padding:13px 10px 13px;
}
.hgroup h1{
	color:#256195;
	font:60px 'proxima_novalight',Arial;
	text-shadow:1px 1px 0 #fff;
	white-space:nowrap;
}

.hgroup h2{
	color:#000;
	font:20px 'proxima_novasemibold'; text-shadow:0px 1px 0px #fff;
	
	padding:10px 0 0;
}
.hgroup h2 span { color:#ec008c}
.hgroup h2 span a { color:#ec008c}
.hgroup h2 span:hover{ text-decoration:underline; color:#ec008c}
.text-page a{ text-decoration:underline; color:#fff; }
.text-page a:hover { text-decoration:underline; color:#3987CC; }

</style>
<!-- Internet Explorer HTML5 enabling script: -->
<!--[if IE]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<body class="bd">
<div class="text-page">Copyright 2013 ShowBizy. All Rights Reserved. <a href="<?php echo WEBSITE_URL;?>">GO TO HOME</a>.</div>
<div id="rocket"></div>
<div class="hgroup">
  <h1>Something Bad Happened</h1>
  <h2> The page you are trying to reach wasn't there.</h2>
  <h2>But the good thing is, we are still here and you can search for something else.</h2>
  <h2><span><a href="<?php echo WEBSITE_URL;?>">GO TO HOME</a></span></h2>
</div>
</div>
</body>
</html>
