<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Userlogin_model extends CI_Model {

    public function loginUser($username,$password,$iplocation)
    {
    	$username	=	addslashes($username);
    	$password	=	base64_encode($password);

		$query 		= 	$this->db->select(array('count(user_id) as cid','user_id','status'))
		                ->where(array(
		                	'username' => $username,
		                	'password' => $password
		                	))
		                ->get('general_authentication');
	    $result 	=	$query->row();
		$total_records= $result->cid;
		$user_id	= 	$result->user_id;
		$status 	= 	$result->status;

		if($total_records > 0 && $status == 'active')
		{
			//Get data from Users table
			$query 		= 	$this->db->select(array('first_name','last_name'))
			                ->where(array(
			                	'status'=> 'active',
			                	'id' 	=> $user_id
			                	))
			                ->get('hrm_users');
		    $result 	=	$query->row();
		    $first_name = 	$result->first_name;
			$last_name	= 	$result->last_name;

			// Get Roles of User
			$query 		= 	$this->db->select('GROUP_CONCAT(role_id) as rids')
			                ->where(array(
			                	'user_id' 	=> $user_id
			                	))
			                ->get('general_user_role');
		    $result 	=	$query->row();
		 	$rids 		= 	$result->rids;
			$rids		=	explode(',', $rids);
			
		 	// Set required data in session
		 	$newdata 	= 	array(
			                   	's_user_id'  	=> $user_id,
			                   	's_first_name'  => $first_name,
			                   	's_last_name' 	=> $last_name,
			                   	's_user_role' 	=> $rids
			               	);
			$this->session->set_userdata($newdata);

			//Insert login data
			if(!empty($iplocation))
			{
				$iplocation	=	json_decode($iplocation);
				$data 	= 	array(
					        'user_id' 	=> 	$user_id,
					        'session_id'=> 	session_id(),
					        'city' 		=> 	$iplocation->cityName,
					        'country' 	=> 	$iplocation->countryName,
					        'ip_address'=> 	$iplocation->ipAddress
						);
				$this->db->insert('hrm_user_loged_detail', $data);
			}
			else
			{
				$data 	= 	array(
					        'user_id' 	=> 	$user_id,
					        'session_id'=> 	session_id(),
					        'city' 		=> 	'',
					        'country' 	=> 	'',
					        'ip_address'=> 	''
						);
				$this->db->insert('hrm_user_loged_detail', $data);	
			}
		}

		return $status;
    }


    public function logoutUser($user_id)
    {
    	//Destroy all sessions
    	$this->session->sess_destroy();

    	//For login details table
    	$data 	= 	array(
					    'logout_time' 	=> 	date("Y-m-d h:i:s")
					);

		$this->db->where('user_id', $user_id);
		$this->db->order_by("id", "desc");
		$this->db->limit(1);
		return $this->db->update('hrm_user_loged_detail', $data);
    }


	public function forgetPasswordUser($username)
    {
    	$username	=	addslashes($username);
		$query 		= 	$this->db->select(array('count(user_id) as cid','user_id','password','status'))
		                ->where(array(
		                	'username' => $username
		                	))
		                ->get('general_authentication');
	    $result 	=	$query->row();
		$total_records= $result->cid;
		$user_id	= 	$result->user_id;
		$password	= 	base64_decode($result->password);
		$status 	= 	$result->status;

		if($total_records > 0 && $status == 'active')
		{
			//Get data from Users table
			$query 		= 	$this->db->select(array('first_name','last_name','work_email'))
			                ->where(array(
			                	'status'=> 'active',
			                	'id' 	=> $user_id
			                	))
			                ->get('hrm_users');
		    $result 	=	$query->row();
		    $first_name = 	$result->first_name;
			$last_name	= 	$result->last_name;
			$work_email	= 	$result->work_email;

			//Insert login data
			$data 	= 	array(
					        'user_id' 	=> 	$user_id,
					        'session_id'=> 	session_id(),
					        'city' 		=> 	$iplocation->cityName,
					        'country' 	=> 	$iplocation->countryName,
					        'ip_address'=> 	$iplocation->ipAddress
						);
			$this->db->insert('emp_forget_password', $data);
		}

		return $status;
    }
}
