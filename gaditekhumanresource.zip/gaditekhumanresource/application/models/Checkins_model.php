<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Checkins_model extends CI_Model {

    public function insertCheckin($user_id,$reviewed_emp_id,$emotion,$rating,$description,$fiscal_year_division_id)
    {
		$data 	= 	array(
			        'user_id' 			=> 	$user_id,
			        'reviewed_emp_id'	=> 	$reviewed_emp_id,
			        'emotion' 			=> 	$emotion,
			        'rating' 			=> 	$rating,
			        'description'		=> 	$description,
			        'fiscal_year_division_id'		=> 	$fiscal_year_division_id
				);

		return $this->db->insert('hrm_checkins', $data);
    }


    public function updateCheckin($user_id,$checkin_id,$status)
    {
    	$data 	= 	array(
					    'status' 	=> 	$status
					);

		$this->db->where('id', $checkin_id);
		$this->db->order_by("id", "desc");
		$this->db->limit(1);
		return $this->db->update('hrm_checkins', $data);
    }


    public function fetchAllCheckins($fetch_status)
    {
    	$array	= 	array();
		$i 		= 	0;

		//Get data from checkins table
		if($fetch_status == 'all')
		{
			$query 	= 	$this->db->select(array('id','user_id','reviewed_emp_id','emotion','rating','description','fiscal_year_division_id','status','created'))
		                ->get('hrm_checkins');
		}
		else
		{
			$query 	= 	$this->db->select(array('id','user_id','reviewed_emp_id','emotion','rating','description','fiscal_year_division_id','status','created'))
		                ->where(array(
		                	'status'=> $fetch_status
		                	))
		                ->get('hrm_checkins');
		}

	    $result =	$query->result();

		foreach($result as $key => $value)
		{
			$array[$i]['id'] 				= 	$value->id;
			$array[$i]['user_id'] 			= 	$value->user_id;
			$array[$i]['reviewed_emp_id'] 	= 	$value->reviewed_emp_id;
			$array[$i]['emotion'] 			= 	$value->emotion;
			$array[$i]['rating'] 			= 	$value->rating;
			$array[$i]['description'] 		= 	$value->description;
			$array[$i]['fiscal_year_division_id']	= 	$value->fiscal_year_division_id;
			$array[$i]['status'] 			= 	$value->status;
			$array[$i]['created'] 			= 	$value->created;
			$i++;
		}

		if($i > 0)
        {
            $status   	=   'success';
            $msg      	=   'Checkins data found successfully.';
        }
        else
        {
            $status   	=   'error';
            $msg      	=   'Sorry! no Checkins data here.';
        }

        $data_final 	= 	array('msg'=>$msg,'status'=>$status,'Checkins'=>$array,'count'=>$i);
		//Return Responce
		return $data_final;
    }


    public function fetchEmployeeList($user_id)
    {
    	$array	= 	array();
		$i 		= 	0;
		$queryE	=	'';

		$query 	= 	$this->db->select(array('value'))
	                ->where(array(
	                	'KEY' => 'checkins_access'
	                	))
	                ->get('general_app_config');
	    $result =	$query->row();
		$checkins_access	= 	$result->value;

		//Get data from employee table
		if($checkins_access == 'all')
		{
			$queryE	= 	$this->db->select(array('id','first_name','last_name','designation_id','department_id'))
		                ->get('hrm_users');
		}
		else
		{
			$queryE	= 	$this->db->select(array('id','first_name','last_name','designation_id','department_id'))
		                ->where(array(
		                	'direct_reporting'=> $user_id
		                	))
		                ->get('hrm_users');
		}

	    $resultE =	$queryE->result();
	    
		foreach($resultE as $key => $value)
		{
			$array[$i]['user_id'] 			= 	$value->id;
			$array[$i]['first_name'] 		= 	$value->first_name;
			$array[$i]['last_name'] 		= 	$value->last_name;
			$array[$i]['designation_id'] 	= 	$value->designation_id;
			$array[$i]['department_id'] 	= 	$value->department_id;
			$i++;
		}

		if($i > 0)
        {
            $status   	=   'success';
            $msg      	=   'Employee data found successfully.';
        }
        else
        {
            $status   	=   'error';
            $msg      	=   'Sorry! no Employee data here.';
        }

        $data_final 	= 	array('msg'=>$msg,'status'=>$status,'Employee'=>$array,'count'=>$i);
		//Return Responce
		return $data_final;
    }

}
